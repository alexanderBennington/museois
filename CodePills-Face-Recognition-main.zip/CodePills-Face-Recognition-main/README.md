# Code Pills: Reconocimiento facial con Javascript y Face API (Tensorflow).

En este vídeo hacemos Reconocimiento Facial con Javascript y Face API usando Tensorflow (machine learning).

Puedes ver el vídeo completo [aquí](https://youtu.be/QbQuNyEgMvY)
